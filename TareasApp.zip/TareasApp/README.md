# Tareas

App de lista de tareas con widget de pantalla de inicio, hecha desde cero
(Kotlin, sin ningún código ni recurso de la app de Transsion).

## Cómo compilar el APK

1. Instala **Android Studio** (última versión estable) si no lo tienes:
   https://developer.android.com/studio
2. Abre Android Studio → **Open** → selecciona esta carpeta (`TareasApp`).
3. Espera a que sincronice Gradle (descargará automáticamente lo que
   necesite; requiere conexión a internet la primera vez).
4. Para probarla en tu móvil: conéctalo por USB con la depuración
   activada y pulsa **Run ▶**.
5. Para generar el APK instalable: **Build → Build Bundle(s)/APK(s) → Build APK(s)**.
   El archivo quedará en `app/build/outputs/apk/debug/app-debug.apk`.
6. Instala ese APK en tu móvil y añade el widget "Tareas" a tu pantalla
   de inicio como cualquier otro widget (mantener pulsado en el
   escritorio → Widgets → Tareas).

## Qué incluye

- **Widget de pantalla de inicio**: tarjeta redondeada crema/amarilla,
  título "Tareas", botón "+" para añadir, lista con círculos que se
  marcan al tocarlos. Sin ningún nombre debajo del widget.
- **App**: pantalla con la lista completa de tareas (añadir, editar,
  marcar y eliminar).
- Los datos se guardan en el propio dispositivo (SharedPreferences),
  compartidos entre la app y el widget.

## Personalizar colores/estilo

Los colores están en `app/src/main/res/values/colors.xml`
(`card_cream`, `accent_yellow`, `text_brown`, etc.) — cámbialos ahí si
quieres ajustar el tono exacto.
